<?php

// phpcs:disable Yoast.NamingConventions.NamespaceName.TooLong -- Needed in the folder structure.

namespace Yoast\WP\SEO\AI\Authorization\Infrastructure;

/**
 * Interface Refresh_Token_User_Meta_Repository_Interface
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
interface Refresh_Token_User_Meta_Repository_Interface extends Token_User_Meta_Repository_Interface {

	public const META_KEY = '_yoast_wpseo_ai_generator_refresh_jwt';
}
